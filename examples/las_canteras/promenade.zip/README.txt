Las Canteras promenade, Las Palmas de Gran Canaria
Extract all files together. From that directory run:
  lodext validate build.json
  lodext build build.json --output model
The verified example produces 1,727 resolved parts and seven unresolved
footprints (partial build, exit code 3). Both CityJSON files are written.
Open model/model.lod1.city.json and inspect objects.csv for individual heights.

Footprints: Direccion General del Catastro, INSPIRE Buildings, municipality
35017, source snapshot 2026-08-21. A selection of 304 buildings and 1734 parts
from the prepared GeoPackage retains mapped geometry, identifiers and storeys.
Source: https://www.catastro.hacienda.gob.es/INSPIRE/Buildings/35/35017-LAS%20PALMAS%20DE%20GRAN%20CANARIA/A.ES.SDGC.BU.35017.zip
Reuse conditions: https://www.catastro.hacienda.gob.es/webinspire/documentos/Licencia.pdf

Cloud: PNOA LiDAR 2023, CC BY 4.0 scne.es (IGN and participating administrations).
Source tiles: PNOA_2023_CANAR_457-3113_H28_NPC02.laz, PNOA_2023_CANAR_457-3114_H28_NPC02.laz
Source catalogue: https://centrodedescargas.cnig.es/
Licence: https://creativecommons.org/licenses/by/4.0/
Approximate reference polygon (latitude, longitude; WGS84):
28.1427312, -15.4328309
28.1422534, -15.431894
28.1395175, -15.4353688
28.13957, -15.4362418
A hull of the polygon and its intersecting building families was expanded by 30 m. All complete families touching that area were retained. The cloud
crop includes the convex hull of the expanded selection and its complete footprints plus another 30 m.
All 981,412 returns in the crop retain their original attributes and precision.
Horizontal CRS: EPSG:4083; source elevations in metres.
The surrounding context is limited by the crop. Heights may differ from a
city-wide reconstruction. The source data retain their respective reuse terms.
